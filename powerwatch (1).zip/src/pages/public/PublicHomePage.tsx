import React, { useEffect, useState, useMemo } from 'react';
import {
  Search,
  MapPin,
  Calendar,
  Clock,
  ExternalLink,
  Map as MapIcon,
  List,
  X,
  Radio,
  ArrowUpRight
} from 'lucide-react';
import { advisoryService, ActiveAdvisoryResponse } from '../../services/advisoryService';
import { Area, PublicScheduleGroup, BrownoutPost } from '../../types';
import { PowerWatchMap, MapAreaSchedule } from '../../components/map/PowerWatchMap';
import { formatDateRange, formatDate, formatDateTime, getScheduleTimeStatus } from '../../utils/formatters';
import { useDebounce } from '../../hooks/useDebounce';

// ==========================================
// Explicit TypeScript Types & Interfaces
// ==========================================

export type DateFilterOption = 'ALL' | 'TODAY' | 'TOMORROW' | 'UPCOMING';
export type StatusFilterOption = 'ALL' | 'ACTIVE_NOW' | 'UPCOMING';
export type MobileTabOption = 'both' | 'map' | 'list';

export interface PublicHomePageProps {
  initialCity?: string;
  onAreaClick?: (area: Area) => void;
}

export interface MinimalScheduleItemProps {
  schedule: PublicScheduleGroup;
  selectedAreaId: string | null;
  onSelectArea: (area: Area) => void;
}

const CITIES = [
  'All Cities',
  'Cebu City',
  'Mandaue City',
  'Talisay City',
  'Consolacion',
  'Liloan',
  'Minglanilla',
  'City of Naga',
  'San Fernando'
] as const;

// ==========================================
// Minimalist Schedule Row Component
// ==========================================

function MinimalScheduleRow({
  schedule,
  selectedAreaId,
  onSelectArea
}: MinimalScheduleItemProps) {
  const timeStatus = getScheduleTimeStatus(
    schedule.scheduleDate,
    schedule.startTime,
    schedule.endTime
  );

  const isActive = timeStatus === 'ongoing';
  const isUpcoming = timeStatus === 'upcoming';

  return (
    <article
      className={`group transition-all duration-200 p-5 rounded-xl border ${
        isActive
          ? 'bg-neutral-50/80 border-neutral-300 ring-1 ring-neutral-200'
          : 'bg-white border-neutral-100 hover:border-neutral-200'
      }`}
    >
      {/* Header Info */}
      <div className="flex items-baseline justify-between gap-4 pb-3 mb-3 border-b border-neutral-100">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            {isActive ? (
              <span className="inline-flex items-center gap-1.5 text-[11px] font-medium text-neutral-900 font-mono tracking-tight">
                <span className="relative flex h-1.5 w-1.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-neutral-900 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-neutral-900"></span>
                </span>
                Active window
              </span>
            ) : isUpcoming ? (
              <span className="text-[11px] font-medium text-neutral-500 font-mono tracking-tight">
                Upcoming
              </span>
            ) : (
              <span className="text-[11px] font-medium text-neutral-400 font-mono tracking-tight">
                Concluded
              </span>
            )}
            <span className="text-neutral-300">/</span>
            <span className="text-[11px] font-mono text-neutral-400">
              {formatDate(schedule.scheduleDate)}
            </span>
          </div>

          <h3 className="text-lg font-light tracking-tight text-neutral-900 font-mono">
            {schedule.timeWindow}
          </h3>
        </div>

        <div className="text-right shrink-0">
          <span className="text-xs font-mono text-neutral-400">
            {schedule.totalAreas ?? schedule.areasByCity.reduce((sum, g) => sum + g.areas.length, 0)} areas
          </span>
        </div>
      </div>

      {/* Grouped Areas by City */}
      <div className="space-y-3 pt-1">
        {schedule.areasByCity.map(group => (
          <div key={group.city} className="space-y-1.5">
            <div className="flex items-center justify-between text-[11px] text-neutral-400 font-mono uppercase tracking-wider">
              <span>{group.city}</span>
              <span className="text-[10px] text-neutral-300">{group.areas.length}</span>
            </div>

            <div className="flex flex-wrap gap-1.5">
              {group.areas.map(area => {
                const isSelected = selectedAreaId === area.id;
                return (
                  <button
                    key={area.id}
                    type="button"
                    onClick={() => onSelectArea(area)}
                    className={`text-xs px-2.5 py-1 rounded-md transition-all duration-150 cursor-pointer ${
                      isSelected
                        ? 'bg-neutral-900 text-white font-medium shadow-xs'
                        : 'bg-neutral-50 hover:bg-neutral-100 text-neutral-600 hover:text-neutral-900'
                    }`}
                  >
                    {area.name}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </article>
  );
}

// ==========================================
// Main Redesigned PublicHomePage Component
// ==========================================

export function PublicHomePage({ initialCity = 'All Cities', onAreaClick }: PublicHomePageProps) {
  const [activeData, setActiveData] = useState<ActiveAdvisoryResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const debouncedSearch = useDebounce(searchQuery, 200);

  // Filters State
  const [selectedCity, setSelectedCity] = useState<string>(initialCity);
  const [selectedDateFilter, setSelectedDateFilter] = useState<DateFilterOption>('ALL');
  const [statusFilter, setStatusFilter] = useState<StatusFilterOption>('ALL');

  // Mobile Map vs List View Switcher
  const [mobileTab, setMobileTab] = useState<MobileTabOption>('both');

  // Selected Area for Map focus & details drawer
  const [selectedAreaId, setSelectedAreaId] = useState<string | null>(null);
  const [focusCoordinates, setFocusCoordinates] = useState<[number, number] | null>(null);

  // Fetch active published advisory
  const fetchActive = () => {
    setLoading(true);
    advisoryService
      .getActiveAdvisory()
      .then(data => {
        setActiveData(data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Failed to fetch active advisory:', err);
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchActive();
  }, []);

  // Dates computation for filters
  const todayStr = useMemo(() => new Date().toISOString().slice(0, 10), []);
  const tomorrowStr = useMemo(() => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    return d.toISOString().slice(0, 10);
  }, []);

  // Distinct affected areas mapped with coordinates for the map
  const affectedAreasForMap: MapAreaSchedule[] = useMemo(() => {
    if (!activeData || !activeData.schedules) return [];

    const areaMap = new Map<string, MapAreaSchedule>();

    activeData.schedules.forEach(schedule => {
      schedule.areasByCity.forEach(group => {
        group.areas.forEach(area => {
          if (!areaMap.has(area.id)) {
            areaMap.set(area.id, {
              area,
              schedules: []
            });
          }
          areaMap.get(area.id)!.schedules.push({
            schedule: {
              id: schedule.id,
              brownoutPostId: activeData.advisory.id,
              scheduleDate: schedule.scheduleDate,
              startTime: schedule.startTime,
              endTime: schedule.endTime,
              scheduleType: schedule.scheduleType,
              status: 'Scheduled',
              createdAt: activeData.advisory.createdAt
            },
            post: activeData.advisory,
            timeWindow: schedule.timeWindow
          });
        });
      });
    });

    return Array.from(areaMap.values());
  }, [activeData]);

  // Filtered schedules according to search query, date filter, status, and city filter
  const filteredSchedules = useMemo(() => {
    if (!activeData || !activeData.schedules) return [];

    return activeData.schedules
      .map(schedule => {
        // Date filter
        if (selectedDateFilter === 'TODAY' && schedule.scheduleDate !== todayStr) {
          return null;
        }
        if (selectedDateFilter === 'TOMORROW' && schedule.scheduleDate !== tomorrowStr) {
          return null;
        }
        if (selectedDateFilter === 'UPCOMING' && schedule.scheduleDate < todayStr) {
          return null;
        }

        // Status filter
        const timeStatus = getScheduleTimeStatus(
          schedule.scheduleDate,
          schedule.startTime,
          schedule.endTime
        );
        if (statusFilter === 'ACTIVE_NOW' && timeStatus !== 'ongoing') {
          return null;
        }
        if (statusFilter === 'UPCOMING' && timeStatus !== 'upcoming') {
          return null;
        }

        // Filter groups by city and search query
        const filteredGroups = schedule.areasByCity
          .map(group => {
            if (selectedCity !== 'All Cities' && group.city !== selectedCity) {
              return null;
            }

            const matchingAreas = group.areas.filter(area => {
              if (!debouncedSearch.trim()) return true;
              const q = debouncedSearch.toLowerCase().trim();
              return (
                area.name.toLowerCase().includes(q) ||
                area.city.toLowerCase().includes(q)
              );
            });

            if (matchingAreas.length === 0) return null;

            return {
              ...group,
              areas: matchingAreas
            };
          })
          .filter(Boolean) as typeof schedule.areasByCity;

        if (filteredGroups.length === 0) return null;

        const totalFilteredAreas = filteredGroups.reduce(
          (sum, g) => sum + g.areas.length,
          0
        );

        return {
          ...schedule,
          areasByCity: filteredGroups,
          totalAreas: totalFilteredAreas
        };
      })
      .filter(Boolean) as PublicScheduleGroup[];
  }, [
    activeData,
    debouncedSearch,
    selectedCity,
    selectedDateFilter,
    statusFilter,
    todayStr,
    tomorrowStr
  ]);

  // Selected Area details for floating minimal drawer
  const selectedAreaDetail = useMemo(() => {
    if (!selectedAreaId) return null;
    return affectedAreasForMap.find(item => item.area.id === selectedAreaId) || null;
  }, [selectedAreaId, affectedAreasForMap]);

  const handleSelectArea = (area: Area) => {
    setSelectedAreaId(area.id);
    if (area.latitude && area.longitude) {
      setFocusCoordinates([area.latitude, area.longitude]);
    }
    if (onAreaClick) {
      onAreaClick(area);
    }
  };

  const handleClearFilters = () => {
    setSearchQuery('');
    setSelectedCity('All Cities');
    setSelectedDateFilter('ALL');
    setStatusFilter('ALL');
  };

  const hasActiveFilters =
    searchQuery.trim().length > 0 ||
    selectedCity !== 'All Cities' ||
    selectedDateFilter !== 'ALL' ||
    statusFilter !== 'ALL';

  if (loading) {
    return (
      <div className="py-24 text-center space-y-3">
        <div className="inline-block w-4 h-4 border-2 border-neutral-300 border-t-neutral-900 rounded-full animate-spin" />
        <p className="text-xs font-mono text-neutral-400 tracking-wide uppercase">
          Loading Metro Cebu Advisories
        </p>
      </div>
    );
  }

  const advisory: BrownoutPost | undefined = activeData?.advisory;

  return (
    <div className="max-w-7xl mx-auto space-y-10 pb-16">
      {/* Editorial Header Section with Generous Breathing Room */}
      <header className="space-y-4 pt-2">
        <div className="flex flex-wrap items-center gap-2.5 text-xs text-neutral-400 font-mono tracking-tight">
          <span className="flex items-center gap-1.5 text-neutral-800 font-medium">
            <Radio className="w-3.5 h-3.5 text-neutral-900" />
            Visayan Electric Advisory
          </span>
          <span>•</span>
          <span>Metro Cebu Grid</span>
          {advisory && (
            <>
              <span>•</span>
              <span>Updated {formatDateTime(advisory.updatedAt)}</span>
            </>
          )}
        </div>

        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
          <div className="space-y-2 max-w-3xl">
            <h1 className="text-3xl sm:text-4xl font-light tracking-tight text-neutral-900">
              {advisory ? advisory.title : 'Metro Cebu PowerWatch'}
            </h1>
            <p className="text-sm sm:text-base text-neutral-500 font-light leading-relaxed max-w-2xl">
              Possible rotational brownout schedules, affected barangays, and geographic boundaries across Metro Cebu based on official utility advisories.
            </p>
          </div>

          {advisory && (
            <div className="flex flex-col items-start lg:items-end gap-1.5 text-xs font-mono text-neutral-500 shrink-0">
              <div className="flex items-center gap-1.5 text-neutral-900 font-medium text-sm">
                <Calendar className="w-3.5 h-3.5 text-neutral-400" />
                <span>{formatDateRange(advisory.startDate, advisory.endDate)}</span>
              </div>
              {advisory.sourceUrl && (
                <a
                  href={advisory.sourceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-neutral-400 hover:text-neutral-900 transition-colors underline underline-offset-4"
                >
                  <span>Official post</span>
                  <ArrowUpRight className="w-3 h-3" />
                </a>
              )}
            </div>
          )}
        </div>

        {/* Minimalist Grid Notice Disclaimer */}
        <p className="text-xs text-neutral-400 leading-relaxed font-light pt-1 border-t border-neutral-100">
          Note: Rotational brownout windows are contingent upon National Grid Corporation of the Philippines (NGCP) dispatch directives and may be adjusted or cancelled as generation balances normalize.
        </p>
      </header>

      {/* Featherlight Minimalist Controls (Search & Filters) */}
      <section className="space-y-3">
        <div className="flex flex-col md:flex-row items-stretch md:items-center gap-2.5">
          {/* Subtle Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              className="w-full pl-10 pr-9 py-2.5 text-sm bg-neutral-50/70 hover:bg-neutral-50 focus:bg-white text-neutral-900 placeholder:text-neutral-400 rounded-lg border border-neutral-200/80 focus:border-neutral-400 focus:outline-none focus:ring-1 focus:ring-neutral-400 transition-all font-sans"
              placeholder="Filter by barangay or area name..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-700 p-0.5 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* City Selector */}
          <div className="shrink-0">
            <select
              value={selectedCity}
              onChange={e => setSelectedCity(e.target.value)}
              className="w-full md:w-auto px-3.5 py-2.5 text-sm bg-neutral-50/70 hover:bg-neutral-50 text-neutral-700 rounded-lg border border-neutral-200/80 focus:border-neutral-400 focus:outline-none focus:ring-1 focus:ring-neutral-400 cursor-pointer transition-all"
            >
              {CITIES.map(c => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>

          {/* Mobile View Switcher */}
          <div className="flex lg:hidden items-center bg-neutral-100 p-0.5 rounded-lg shrink-0">
            <button
              type="button"
              onClick={() => setMobileTab('map')}
              className={`flex-1 flex items-center justify-center gap-1 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                mobileTab === 'map' ? 'bg-white text-neutral-900 shadow-xs' : 'text-neutral-500'
              }`}
            >
              <MapIcon className="w-3.5 h-3.5" />
              Map
            </button>
            <button
              type="button"
              onClick={() => setMobileTab('list')}
              className={`flex-1 flex items-center justify-center gap-1 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                mobileTab === 'list' ? 'bg-white text-neutral-900 shadow-xs' : 'text-neutral-500'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              List
            </button>
          </div>
        </div>

        {/* Date Filter Pills */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
          <div className="flex items-center gap-1">
            {(
              [
                { id: 'ALL', label: 'All dates' },
                { id: 'TODAY', label: 'Today' },
                { id: 'TOMORROW', label: 'Tomorrow' },
                { id: 'UPCOMING', label: 'Upcoming' }
              ] as const
            ).map(opt => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setSelectedDateFilter(opt.id)}
                className={`px-3 py-1 rounded-md text-xs font-mono transition-all cursor-pointer ${
                  selectedDateFilter === opt.id
                    ? 'bg-neutral-900 text-white font-medium'
                    : 'text-neutral-500 hover:text-neutral-900 hover:bg-neutral-100/70'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>

          {hasActiveFilters && (
            <button
              type="button"
              onClick={handleClearFilters}
              className="text-xs text-neutral-400 hover:text-neutral-900 transition-colors underline underline-offset-4 cursor-pointer font-mono"
            >
              Reset filters
            </button>
          )}
        </div>
      </section>

      {/* Main Responsive Grid Layout */}
      <main className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Map Column */}
        <section
          aria-label="Affected geographic areas map"
          className={`lg:col-span-7 space-y-3 ${
            mobileTab === 'list' ? 'hidden lg:block' : 'block'
          }`}
        >
          <div className="flex items-baseline justify-between px-0.5 text-xs font-mono text-neutral-400">
            <span className="uppercase tracking-wider">Geographic Map</span>
            <span>{affectedAreasForMap.length} affected areas</span>
          </div>

          <div className="rounded-xl overflow-hidden border border-neutral-200/80 bg-neutral-50">
            <PowerWatchMap
              affectedAreas={affectedAreasForMap}
              selectedAreaId={selectedAreaId}
              onSelectArea={areaId => {
                const found = affectedAreasForMap.find(a => a.area.id === areaId);
                if (found) handleSelectArea(found.area);
              }}
              focusCoordinates={focusCoordinates}
              height="580px"
            />
          </div>
        </section>

        {/* Schedules Column */}
        <section
          aria-label="Brownout schedule breakdown"
          className={`lg:col-span-5 space-y-3 ${
            mobileTab === 'map' ? 'hidden lg:block' : 'block'
          }`}
        >
          <div className="flex items-baseline justify-between px-0.5 text-xs font-mono text-neutral-400">
            <span className="uppercase tracking-wider">Time Windows</span>
            <span>
              {filteredSchedules.length} {filteredSchedules.length === 1 ? 'schedule' : 'schedules'}
            </span>
          </div>

          {filteredSchedules.length > 0 ? (
            <div className="space-y-3 max-h-[640px] overflow-y-auto pr-1">
              {filteredSchedules.map(schedule => (
                <MinimalScheduleRow
                  key={schedule.id}
                  schedule={schedule}
                  selectedAreaId={selectedAreaId}
                  onSelectArea={handleSelectArea}
                />
              ))}
            </div>
          ) : (
            <div className="p-12 text-center border border-dashed border-neutral-200 rounded-xl space-y-2">
              <p className="text-sm font-light text-neutral-600">
                No matching schedules found
              </p>
              <p className="text-xs text-neutral-400">
                Try clearing your search query or switching to All Cities.
              </p>
              {hasActiveFilters && (
                <button
                  type="button"
                  onClick={handleClearFilters}
                  className="mt-3 inline-block text-xs font-mono text-neutral-900 underline underline-offset-4 cursor-pointer"
                >
                  Clear all filters
                </button>
              )}
            </div>
          )}
        </section>
      </main>

      {/* Minimal Floating Drawer for Selected Area */}
      {selectedAreaDetail && (
        <aside
          aria-label="Selected area details"
          className="fixed bottom-6 right-6 z-40 max-w-sm w-full bg-white/95 backdrop-blur-md rounded-xl shadow-lg border border-neutral-200 p-5 space-y-3 animate-in fade-in slide-in-from-bottom-3"
        >
          <div className="flex items-start justify-between gap-3 pb-2 border-b border-neutral-100">
            <div>
              <span className="text-[10px] font-mono text-neutral-400 uppercase tracking-wider block">
                Selected Barangay
              </span>
              <h4 className="text-base font-medium text-neutral-900 mt-0.5">
                {selectedAreaDetail.area.name}
              </h4>
              <p className="text-xs text-neutral-500">{selectedAreaDetail.area.city}</p>
            </div>
            <button
              type="button"
              onClick={() => setSelectedAreaId(null)}
              className="text-neutral-400 hover:text-neutral-700 p-1 rounded-md hover:bg-neutral-100 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-2">
            <span className="text-[11px] font-mono text-neutral-400 block">
              Associated Windows ({selectedAreaDetail.schedules.length})
            </span>
            <div className="max-h-36 overflow-y-auto space-y-1.5 pr-1">
              {selectedAreaDetail.schedules.map((s, idx) => (
                <div
                  key={idx}
                  className="p-2.5 rounded-lg bg-neutral-50 text-neutral-900 font-mono text-xs flex items-center justify-between"
                >
                  <span className="text-neutral-500">
                    {formatDate(s.schedule.scheduleDate)}
                  </span>
                  <span className="font-medium">
                    {s.schedule.startTime} – {s.schedule.endTime}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </aside>
      )}
    </div>
  );
}
