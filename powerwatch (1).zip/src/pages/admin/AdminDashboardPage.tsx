import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  FileUp,
  FileText,
  MapPin,
  Clock,
  CheckCircle,
  AlertCircle,
  Eye,
  Edit,
  ArrowRight,
  ExternalLink
} from 'lucide-react';
import { advisoryService } from '../../services/advisoryService';
import { BrownoutPost } from '../../types';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { Card, CardHeader, CardBody } from '../../components/common/Card';
import { LoadingState } from '../../components/common/EmptyState';
import { formatDate, formatDateTime } from '../../utils/formatters';

export function AdminDashboardPage() {
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    advisoryService
      .getDashboardStats()
      .then(data => {
        setStats(data);
        setLoading(false);
      })
      .catch(err => {
        setError(err.message || 'Failed to load dashboard metrics.');
        setLoading(false);
      });
  }, []);

  if (loading) return <LoadingState message="Loading dashboard metrics..." />;
  if (error) {
    return (
      <div className="p-6 bg-rose-50 text-rose-800 rounded-xl border border-rose-200">
        <p className="font-semibold">{error}</p>
      </div>
    );
  }

  const statCards = [
    {
      title: 'Published Advisories',
      value: stats?.publishedPosts || 0,
      icon: CheckCircle,
      color: 'text-emerald-600 bg-emerald-50 border-emerald-200'
    },
    {
      title: 'Drafts for Review',
      value: stats?.draftPosts || 0,
      icon: AlertCircle,
      color: 'text-amber-600 bg-amber-50 border-amber-200'
    },
    {
      title: 'Active Schedules',
      value: stats?.activeSchedules || 0,
      icon: Clock,
      color: 'text-blue-600 bg-blue-50 border-blue-200'
    },
    {
      title: 'Registered Barangays',
      value: stats?.totalAreas || 0,
      icon: MapPin,
      color: 'text-slate-600 bg-slate-100 border-slate-200'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Top Welcome & Quick Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <h1 className="text-2xl font-black text-slate-950 tracking-tight">
            Advisory Management Dashboard
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Import, parse, and verify Visayan Electric rotational brownout schedules for Metro Cebu.
          </p>
        </div>
        <div className="flex items-center gap-3 shrink-0">
          <Link to="/admin/advisories/import">
            <Button variant="secondary" icon={<FileUp className="w-4 h-4" />}>
              Import New Advisory
            </Button>
          </Link>
          <Link to="/" target="_blank">
            <Button variant="outline" icon={<Eye className="w-4 h-4" />}>
              View Live Map
            </Button>
          </Link>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map(s => {
          const Icon = s.icon;
          return (
            <Card key={s.title}>
              <CardBody className="flex items-center justify-between p-5">
                <div>
                  <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                    {s.title}
                  </p>
                  <p className="text-3xl font-black text-slate-900 mt-1">{s.value}</p>
                </div>
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center border ${s.color}`}>
                  <Icon className="w-6 h-6" />
                </div>
              </CardBody>
            </Card>
          );
        })}
      </div>

      {/* Recent Advisories Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between w-full">
            <div>
              <h2 className="text-base font-bold text-slate-900">Recent Advisories</h2>
              <p className="text-xs text-slate-500">Official posts imported into PowerWatch</p>
            </div>
            <Link
              to="/admin/advisories"
              className="text-xs font-semibold text-amber-700 hover:text-amber-900 flex items-center gap-1"
            >
              <span>View All</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </CardHeader>
        <CardBody className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600">
              <thead className="bg-slate-50 text-xs font-semibold uppercase text-slate-500 border-b border-slate-100">
                <tr>
                  <th className="px-5 py-3">Advisory Title</th>
                  <th className="px-5 py-3">Dates</th>
                  <th className="px-5 py-3">Status</th>
                  <th className="px-5 py-3">Schedules</th>
                  <th className="px-5 py-3">Last Modified</th>
                  <th className="px-5 py-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {stats?.recentAdvisories && stats.recentAdvisories.length > 0 ? (
                  stats.recentAdvisories.map((post: BrownoutPost) => (
                    <tr key={post.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="px-5 py-3.5 font-medium text-slate-900 max-w-xs truncate">
                        {post.title}
                        {post.sourceUrl && (
                          <a
                            href={post.sourceUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-[11px] text-blue-600 hover:text-blue-800 ml-2"
                          >
                            <ExternalLink className="w-2.5 h-2.5" />
                          </a>
                        )}
                      </td>
                      <td className="px-5 py-3.5 text-xs text-slate-600">
                        {formatDate(post.startDate)} – {formatDate(post.endDate)}
                      </td>
                      <td className="px-5 py-3.5">
                        <Badge
                          variant={
                            post.status === 'Published'
                              ? 'green'
                              : post.status === 'Draft'
                              ? 'amber'
                              : 'slate'
                          }
                          size="sm"
                          dot={post.status === 'Published'}
                        >
                          {post.status}
                        </Badge>
                      </td>
                      <td className="px-5 py-3.5 text-xs font-semibold text-slate-700">
                        {post.schedules?.length || 0} windows
                      </td>
                      <td className="px-5 py-3.5 text-xs text-slate-500">
                        {formatDateTime(post.updatedAt)}
                      </td>
                      <td className="px-5 py-3.5 text-right">
                        <Link to={`/admin/advisories/review/${post.id}`}>
                          <Button size="sm" variant="outline" icon={<Edit className="w-3.5 h-3.5" />}>
                            Review / Edit
                          </Button>
                        </Link>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="px-5 py-8 text-center text-slate-400 italic">
                      No advisories imported yet. Click &apos;Import New Advisory&apos; above.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
