import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Zap, ShieldCheck, Lock, AlertCircle, ArrowLeft } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
import { Alert } from '../../components/common/Alert';

export function AdminLoginPage() {
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const from = (location.state as any)?.from?.pathname || '/admin';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    try {
      await login(username, password);
      navigate(from, { replace: true });
    } catch (err: any) {
      setError(err.message || 'Invalid username or password.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center px-4">
        <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-amber-500 text-slate-950 font-black shadow-lg mb-4">
          <Zap className="w-7 h-7 fill-current" />
        </div>
        <h2 className="text-2xl font-extrabold text-white tracking-tight">
          PowerWatch Admin Portal
        </h2>
        <p className="mt-1 text-sm text-slate-400">
          Official Visayan Electric Advisory Management
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md px-4">
        <div className="bg-white py-8 px-6 shadow-xl rounded-2xl sm:px-10 border border-slate-200">
          <form className="space-y-5" onSubmit={handleSubmit}>
            {error && (
              <Alert type="error" title="Authentication Error">
                {error}
              </Alert>
            )}

            <Input
              label="Username"
              type="text"
              required
              value={username}
              onChange={e => setUsername(e.target.value)}
              placeholder="e.g. admin"
              autoComplete="username"
            />

            <Input
              label="Password"
              type="password"
              required
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="••••••••••••"
              autoComplete="current-password"
            />

            <Button
              type="submit"
              variant="primary"
              size="lg"
              className="w-full mt-2"
              isLoading={isLoading}
              icon={<Lock className="w-4 h-4" />}
            >
              Sign In to Admin Portal
            </Button>
          </form>

          {/* Development / Initial Credentials Helper */}
          <div className="mt-6 pt-5 border-t border-slate-100 text-xs text-slate-600 bg-slate-50 p-3.5 rounded-lg">
            <div className="flex items-center gap-1.5 font-semibold text-slate-800 mb-1">
              <ShieldCheck className="w-4 h-4 text-amber-600" />
              Default Administrator Credentials:
            </div>
            <div className="font-mono text-[11px] space-y-0.5 text-slate-700">
              <div>Username: <strong className="text-slate-900">admin</strong></div>
              <div>Password: <strong className="text-slate-900">AdminPowerWatch2026!</strong></div>
            </div>
            <button
              type="button"
              onClick={() => {
                setUsername('admin');
                setPassword('AdminPowerWatch2026!');
              }}
              className="mt-2 text-amber-700 hover:text-amber-900 font-semibold underline text-[11px] cursor-pointer"
            >
              Fill default credentials
            </button>
          </div>

          <div className="mt-6 text-center">
            <button
              type="button"
              onClick={() => navigate('/')}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-900 transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              Back to Public Schedule
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
