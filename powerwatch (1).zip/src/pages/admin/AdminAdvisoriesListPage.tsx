import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { FileText, FileUp, Edit, ExternalLink, Archive, Send, Plus } from 'lucide-react';
import { advisoryService } from '../../services/advisoryService';
import { BrownoutPost, PostStatus } from '../../types';
import { Button } from '../../components/common/Button';
import { Badge } from '../../components/common/Badge';
import { Card, CardHeader, CardBody } from '../../components/common/Card';
import { LoadingState } from '../../components/common/EmptyState';
import { formatDate, formatDateTime } from '../../utils/formatters';

export function AdminAdvisoriesListPage() {
  const [advisories, setAdvisories] = useState<BrownoutPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  useEffect(() => {
    fetchAdvisories();
  }, []);

  const fetchAdvisories = () => {
    setLoading(true);
    advisoryService
      .getAllAdvisories()
      .then(data => {
        setAdvisories(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  };

  const handleArchive = async (id: string) => {
    if (!window.confirm('Archive this advisory?')) return;
    try {
      await advisoryService.archiveAdvisory(id);
      fetchAdvisories();
    } catch (err: any) {
      alert(err.message || 'Failed to archive.');
    }
  };

  const filteredAdvisories = advisories.filter(a => {
    if (statusFilter === 'ALL') return true;
    return a.status === statusFilter;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <h1 className="text-xl font-black text-slate-950 tracking-tight flex items-center gap-2">
            <FileText className="w-5 h-5 text-amber-500" />
            All Official Advisories
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage drafts, published schedules, and historical archived advisories.
          </p>
        </div>
        <Link to="/admin/advisories/import">
          <Button variant="secondary" icon={<FileUp className="w-4 h-4" />}>
            Import New Advisory
          </Button>
        </Link>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        {['ALL', 'Draft', 'Published', 'Archived'].map(tab => (
          <button
            key={tab}
            type="button"
            onClick={() => setStatusFilter(tab)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
              statusFilter === tab
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100'
            }`}
          >
            {tab === 'ALL' ? 'All Advisories' : tab}
            <span className="ml-1.5 text-[10px] opacity-75">
              ({tab === 'ALL' ? advisories.length : advisories.filter(a => a.status === tab).length})
            </span>
          </button>
        ))}
      </div>

      {/* Advisories Table */}
      <Card>
        <CardBody className="p-0">
          {loading ? (
            <LoadingState message="Loading advisories..." />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm text-slate-600">
                <thead className="bg-slate-50 text-xs font-semibold uppercase text-slate-500 border-b border-slate-100">
                  <tr>
                    <th className="px-5 py-3">Advisory Title</th>
                    <th className="px-5 py-3">Dates</th>
                    <th className="px-5 py-3">Status</th>
                    <th className="px-5 py-3">Schedules</th>
                    <th className="px-5 py-3">Created</th>
                    <th className="px-5 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredAdvisories.length > 0 ? (
                    filteredAdvisories.map(post => (
                      <tr key={post.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="px-5 py-3.5 font-medium text-slate-900 max-w-sm truncate">
                          {post.title}
                          {post.sourceUrl && (
                            <a
                              href={post.sourceUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1 text-[11px] text-blue-600 hover:text-blue-800 ml-2"
                              title="Original Facebook post"
                            >
                              <ExternalLink className="w-2.5 h-2.5" />
                            </a>
                          )}
                        </td>
                        <td className="px-5 py-3.5 text-xs text-slate-600 whitespace-nowrap">
                          {formatDate(post.startDate)} – {formatDate(post.endDate)}
                        </td>
                        <td className="px-5 py-3.5">
                          <Badge
                            variant={
                              post.status === 'Published'
                                ? 'green'
                                : post.status === 'Draft'
                                ? 'amber'
                                : 'slate'
                            }
                            size="sm"
                            dot={post.status === 'Published'}
                          >
                            {post.status}
                          </Badge>
                        </td>
                        <td className="px-5 py-3.5 text-xs font-semibold text-slate-700">
                          {post.schedules?.length || 0} time slots
                        </td>
                        <td className="px-5 py-3.5 text-xs text-slate-500 whitespace-nowrap">
                          {formatDateTime(post.createdAt)}
                        </td>
                        <td className="px-5 py-3.5 text-right space-x-2 whitespace-nowrap">
                          <Link to={`/admin/advisories/review/${post.id}`}>
                            <Button size="sm" variant="outline" icon={<Edit className="w-3.5 h-3.5" />}>
                              Review / Edit
                            </Button>
                          </Link>
                          {post.status === 'Published' && (
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleArchive(post.id)}
                              className="text-rose-600 hover:text-rose-700 hover:bg-rose-50"
                            >
                              Archive
                            </Button>
                          )}
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={6} className="px-5 py-10 text-center text-slate-400 italic">
                        No advisories found for filter &quot;{statusFilter}&quot;.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </CardBody>
      </Card>
    </div>
  );
}
