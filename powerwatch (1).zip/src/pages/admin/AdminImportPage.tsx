import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  FileUp,
  Image as ImageIcon,
  Sparkles,
  AlertTriangle,
  FileText,
  Link as LinkIcon,
  CheckCircle2,
  ArrowRight,
  Info
} from 'lucide-react';
import { advisoryService } from '../../services/advisoryService';
import { Button } from '../../components/common/Button';
import { Input, Textarea } from '../../components/common/Input';
import { Alert } from '../../components/common/Alert';
import { Card, CardBody } from '../../components/common/Card';
import { DuplicateWarning } from '../../types';

// Sample realistic Facebook advisory text for quick testing
const SAMPLE_FACEBOOK_ADVISORY = `ADVISORY: REVISED POSSIBLE ROTATIONAL BROWNOUTS
DAILY | SEPTEMBER 6-8, 2026
10:00AM–11:00PM

Due to the current power supply situation, Visayan Electric will implement possible rotational brownouts in parts of its franchise area to help prevent system collapse.

10:00 AM–12:30 PM
Cebu City: Guadalupe, Lahug, Capitol Site, Mabolo, Kasambagan
Mandaue City: Centro, Subangdaku, Tipolo, Bakilid

01:00 PM–03:30 PM
Cebu City: Basak San Nicolas, Punta Princesa, Mambaling, Tisa
Talisay City: Tabunok, Bulacao, San Isidro, Dumlog

04:00 PM–06:30 PM
Cebu City: Apas, Banilad, Talamban, Bacayan
Consolacion: Casili, Danlag, Pitogo, Poblacion

Source: Visayan Electric
Note: Power will immediately be restored once power supply situation stabilizes.`;

export function AdminImportPage() {
  const navigate = useNavigate();

  const [rawText, setRawText] = useState('');
  const [sourceUrl, setSourceUrl] = useState('');
  const [source, setSource] = useState('Visayan Electric');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [ocrStatus, setOcrStatus] = useState<{ isAvailable: boolean; engine: string } | null>(null);

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [duplicateWarning, setDuplicateWarning] = useState<DuplicateWarning | null>(null);

  useEffect(() => {
    advisoryService.getOcrStatus().then(status => setOcrStatus(status)).catch(() => {});
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSelectedFile(file);
    const reader = new FileReader();
    reader.onload = () => {
      setImagePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleImport = async (forceContinue: boolean = false) => {
    if (!rawText.trim() && !imagePreview) {
      setError('Please paste the Facebook post text or upload an advisory image.');
      return;
    }

    setError(null);
    setIsLoading(true);

    try {
      const response = await advisoryService.importAdvisory({
        text: rawText,
        sourceUrl: sourceUrl.trim() || undefined,
        source: source.trim() || 'Visayan Electric',
        imageDataUrl: imagePreview || undefined,
        imageFileName: selectedFile?.name
      });

      // If duplicate detected and administrator hasn't bypassed it yet
      if (response.duplicateWarning?.isDuplicate && !forceContinue) {
        setDuplicateWarning(response.duplicateWarning);
        setIsLoading(false);
        return;
      }

      // Success! Proceed to review interface
      navigate(`/admin/advisories/review/${response.advisory.id}`, {
        state: {
          importedFresh: true,
          duplicateWarning: response.duplicateWarning
        }
      });
    } catch (err: any) {
      setError(err.message || 'Failed to import and parse the advisory.');
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Title */}
      <div>
        <h1 className="text-2xl font-black text-slate-950 tracking-tight flex items-center gap-2.5">
          <FileUp className="w-7 h-7 text-amber-500" />
          Import Official Visayan Electric Advisory
        </h1>
        <p className="text-sm text-slate-600 mt-1">
          Paste the text directly from the official Facebook post or upload an image. The parser will extract rotational brownout schedules, times, and affected barangays into a Draft for review.
        </p>
      </div>

      {error && (
        <Alert type="error" title="Import Error">
          {error}
        </Alert>
      )}

      {/* Duplicate Warning Prompt */}
      {duplicateWarning && (
        <Alert
          type="warning"
          title="Possible Duplicate Advisory Detected"
          action={
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  const targetId = duplicateWarning.existingPostId || duplicateWarning.existingAdvisory?.id;
                  if (targetId) navigate(`/admin/advisories/review/${targetId}`);
                }}
              >
                View Existing
              </Button>
              <Button
                size="sm"
                variant="secondary"
                onClick={() => handleImport(true)}
              >
                Continue Anyway
              </Button>
            </div>
          }
        >
          {duplicateWarning.message}
          <div className="text-xs text-amber-900 mt-1 font-mono">
            Existing: {duplicateWarning.existingPostTitle || duplicateWarning.existingAdvisory?.title}
          </div>
        </Alert>
      )}

      {/* Main Form */}
      <Card>
        <CardBody className="p-6 space-y-6">
          {/* Facebook Post URL & Source */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              label="Facebook Advisory Post URL (Optional)"
              placeholder="https://www.facebook.com/visayanelectric/posts/..."
              value={sourceUrl}
              onChange={e => setSourceUrl(e.target.value)}
              icon={<LinkIcon className="w-4 h-4" />}
              helperText="Enables 'View Original Advisory' link for the public"
            />
            <Input
              label="Source Authority"
              value={source}
              onChange={e => setSource(e.target.value)}
              helperText="Official utility source (Visayan Electric)"
            />
          </div>

          {/* Direct Text Paste (Primary) */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-slate-700 uppercase tracking-wide flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-slate-500" />
                Raw Facebook Post Text (Primary Method)
              </label>
              <button
                type="button"
                onClick={() => setRawText(SAMPLE_FACEBOOK_ADVISORY)}
                className="text-xs font-semibold text-amber-700 hover:text-amber-900 underline cursor-pointer"
              >
                Load Sample VECO Post
              </button>
            </div>
            <Textarea
              rows={12}
              placeholder={`Paste the entire Visayan Electric Facebook advisory here...
Example:
ADVISORY: REVISED POSSIBLE ROTATIONAL BROWNOUTS
DAILY | SEPTEMBER 5, 2026
10:00 AM–12:30 PM
Cebu City: Guadalupe, Lahug, Mabolo
Mandaue City: Centro, Subangdaku`}
              value={rawText}
              onChange={e => setRawText(e.target.value)}
            />
          </div>

          {/* Modular Image Upload / OCR Architecture */}
          <div className="pt-4 border-t border-slate-100">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-slate-500" />
                <span className="text-xs font-semibold text-slate-700 uppercase tracking-wide">
                  Optional Advisory Image / Graphic
                </span>
              </div>
              <span className="text-[11px] text-slate-400">
                OCR Status: {ocrStatus?.isAvailable ? 'Gemini Flash Vision' : 'Manual text paste fallback'}
              </span>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-4 p-4 border border-dashed border-slate-300 rounded-xl bg-slate-50/60">
              {imagePreview ? (
                <div className="relative shrink-0">
                  <img
                    src={imagePreview}
                    alt="Advisory preview"
                    className="w-24 h-24 object-cover rounded-lg border border-slate-300 shadow-xs"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      setImagePreview(null);
                      setSelectedFile(null);
                    }}
                    className="absolute -top-1.5 -right-1.5 bg-rose-600 text-white rounded-full p-0.5 text-xs shadow-xs"
                  >
                    &times;
                  </button>
                </div>
              ) : (
                <div className="w-16 h-16 rounded-xl bg-slate-200 flex items-center justify-center text-slate-400 shrink-0">
                  <ImageIcon className="w-8 h-8" />
                </div>
              )}

              <div className="space-y-1 text-center sm:text-left flex-1">
                <p className="text-xs text-slate-600">
                  Upload screenshot or graphic advisory from Visayan Electric Facebook.
                </p>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  className="text-xs text-slate-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-md file:border-0 file:text-xs file:font-semibold file:bg-slate-200 file:text-slate-800 hover:file:bg-slate-300 cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Information Callout */}
          <div className="bg-blue-50/70 p-3.5 rounded-xl border border-blue-200/80 text-xs text-blue-900 flex items-start gap-2.5">
            <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <span className="font-bold">Safe Draft Workflow:</span>
              <p>
                Importing will parse this advisory and create an unpublished <strong>Draft</strong>. You will be taken to the
                Review Interface where you can adjust schedules, inspect matched barangays, resolve any unrecognized locations,
                and review everything before publishing to the public map.
              </p>
            </div>
          </div>

          {/* Submit Action */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate('/admin')}
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="secondary"
              size="lg"
              isLoading={isLoading}
              onClick={() => handleImport(false)}
              icon={<Sparkles className="w-4 h-4" />}
            >
              Parse & Review Advisory
            </Button>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
