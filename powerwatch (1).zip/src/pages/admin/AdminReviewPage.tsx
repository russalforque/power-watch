import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  FileText,
  Save,
  Send,
  Archive,
  RefreshCw,
  Plus,
  Trash2,
  AlertTriangle,
  CheckCircle2,
  HelpCircle,
  ExternalLink,
  ArrowLeft,
  Clock,
  MapPin,
  Calendar,
  Zap,
  Eye
} from 'lucide-react';
import { advisoryService } from '../../services/advisoryService';
import { areaService } from '../../services/areaService';
import { BrownoutPost, Area, BrownoutScheduleArea } from '../../types';
import { Button } from '../../components/common/Button';
import { Input, Select } from '../../components/common/Input';
import { Badge } from '../../components/common/Badge';
import { Alert } from '../../components/common/Alert';
import { Card, CardHeader, CardBody } from '../../components/common/Card';
import { Modal } from '../../components/common/Modal';
import { LoadingState } from '../../components/common/EmptyState';
import { formatDate } from '../../utils/formatters';

interface EditableSchedule {
  id: string;
  scheduleDate: string;
  startTime: string;
  endTime: string;
  scheduleType: 'PossibleRotationalBrownout';
  areas: {
    rawAreaName: string;
    city: string;
    matchedAreaId?: string;
    isMatched: boolean;
  }[];
}

export function AdminReviewPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [advisory, setAdvisory] = useState<BrownoutPost | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Form State
  const [title, setTitle] = useState('');
  const [source, setSource] = useState('Visayan Electric');
  const [sourceUrl, setSourceUrl] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [schedules, setSchedules] = useState<EditableSchedule[]>([]);

  // Known areas database for matching
  const [knownAreas, setKnownAreas] = useState<Area[]>([]);

  // Modals
  const [isPublishModalOpen, setIsPublishModalOpen] = useState(false);
  const [isNewAreaModalOpen, setIsNewAreaModalOpen] = useState(false);
  const [activeAreaTarget, setActiveAreaTarget] = useState<{ schedIdx: number; areaIdx: number } | null>(null);
  const [newAreaName, setNewAreaName] = useState('');
  const [newAreaCity, setNewAreaCity] = useState('Cebu City');

  // Input for adding new area to schedule
  const [newAreaInputs, setNewAreaInputs] = useState<Record<number, { name: string; city: string }>>({});

  useEffect(() => {
    if (!id) return;

    Promise.all([
      advisoryService.getAdvisoryById(id),
      areaService.getAreas()
    ])
      .then(([post, areas]) => {
        setAdvisory(post);
        setKnownAreas(areas);
        setTitle(post.title);
        setSource(post.source);
        setSourceUrl(post.sourceUrl || '');
        setStartDate(post.startDate);
        setEndDate(post.endDate);

        // Convert schedules to editable state
        const editableSchedules: EditableSchedule[] = (post.schedules || []).map(s => ({
          id: s.id,
          scheduleDate: s.scheduleDate,
          startTime: s.startTime,
          endTime: s.endTime,
          scheduleType: 'PossibleRotationalBrownout',
          areas: (s.areas || []).map(a => ({
            rawAreaName: a.rawAreaName || a.name,
            city: a.city,
            matchedAreaId: (a as any).matchedAreaId || a.id,
            isMatched: Boolean(a.isMatched ?? true)
          }))
        }));

        setSchedules(editableSchedules);
        setLoading(false);
      })
      .catch(err => {
        setError(err.message || 'Failed to load advisory for review.');
        setLoading(false);
      });
  }, [id]);

  // Handle schedule changes
  const updateScheduleField = (index: number, field: keyof EditableSchedule, value: any) => {
    const updated = [...schedules];
    (updated[index] as any)[field] = value;
    setSchedules(updated);
  };

  const removeSchedule = (index: number) => {
    if (schedules.length <= 1) {
      alert('An advisory must have at least one schedule window.');
      return;
    }
    const updated = schedules.filter((_, i) => i !== index);
    setSchedules(updated);
  };

  const addSchedule = () => {
    const newSched: EditableSchedule = {
      id: `sched-${Date.now()}`,
      scheduleDate: startDate || new Date().toISOString().slice(0, 10),
      startTime: '10:00 AM',
      endTime: '12:30 PM',
      scheduleType: 'PossibleRotationalBrownout',
      areas: []
    };
    setSchedules([...schedules, newSched]);
  };

  // Handle area changes inside schedule
  const removeAreaFromSchedule = (schedIdx: number, areaIdx: number) => {
    const updated = [...schedules];
    updated[schedIdx].areas = updated[schedIdx].areas.filter((_, i) => i !== areaIdx);
    setSchedules(updated);
  };

  const addAreaToSchedule = (schedIdx: number) => {
    const input = newAreaInputs[schedIdx] || { name: '', city: 'Cebu City' };
    if (!input.name.trim()) return;

    const trimmed = input.name.trim();
    // Try to match with known areas
    const matched = knownAreas.find(
      a => a.normalizedName === trimmed.toLowerCase() && a.city.toLowerCase() === input.city.toLowerCase()
    );

    const updated = [...schedules];
    updated[schedIdx].areas.push({
      rawAreaName: trimmed,
      city: input.city,
      matchedAreaId: matched?.id,
      isMatched: Boolean(matched)
    });

    setSchedules(updated);
    setNewAreaInputs({
      ...newAreaInputs,
      [schedIdx]: { name: '', city: input.city }
    });
  };

  // Match an unknown area to an existing known area
  const assignKnownArea = (schedIdx: number, areaIdx: number, matchedAreaId: string) => {
    const selected = knownAreas.find(a => a.id === matchedAreaId);
    if (!selected) return;

    const updated = [...schedules];
    updated[schedIdx].areas[areaIdx].matchedAreaId = selected.id;
    updated[schedIdx].areas[areaIdx].city = selected.city;
    updated[schedIdx].areas[areaIdx].isMatched = true;
    setSchedules(updated);
  };

  // Register new area into DB permanently and link
  const handleRegisterNewArea = async () => {
    if (!newAreaName.trim() || !activeAreaTarget) return;

    try {
      const created = await areaService.createArea({
        name: newAreaName.trim(),
        city: newAreaCity,
        latitude: 10.3157, // Default Metro Cebu center
        longitude: 123.8854
      });

      setKnownAreas([...knownAreas, created]);

      // Assign to target
      assignKnownArea(activeAreaTarget.schedIdx, activeAreaTarget.areaIdx, created.id);
      setIsNewAreaModalOpen(false);
      setNewAreaName('');
      setActiveAreaTarget(null);
    } catch (err: any) {
      alert(err.message || 'Failed to register new area.');
    }
  };

  // Re-run Parser
  const handleReparse = async () => {
    if (!id || !window.confirm('Re-running the parser will overwrite current manual edits with fresh parsing results from the original text. Continue?')) {
      return;
    }

    setSaving(true);
    try {
      const parsed = await advisoryService.reparseAdvisory(id);
      setTitle(parsed.title);
      setStartDate(parsed.startDate);
      setEndDate(parsed.endDate);
      setSchedules(
        parsed.schedules.map((s, idx) => ({
          id: `sched-reparsed-${idx}`,
          scheduleDate: s.date,
          startTime: s.startTime,
          endTime: s.endTime,
          scheduleType: s.scheduleType,
          areas: s.areas.map(a => ({
            rawAreaName: a.rawName,
            city: a.city,
            matchedAreaId: a.matchedAreaId,
            isMatched: a.isMatched
          }))
        }))
      );
      setSuccessMessage('Successfully re-parsed original advisory text.');
    } catch (err: any) {
      setError(err.message || 'Failed to re-parse advisory.');
    } finally {
      setSaving(false);
    }
  };

  // Save changes
  const handleSave = async () => {
    if (!id) return;
    setSaving(true);
    setError(null);
    setSuccessMessage(null);

    try {
      const updated = await advisoryService.updateAdvisory(id, {
        title,
        source,
        sourceUrl: sourceUrl.trim() || undefined,
        startDate,
        endDate,
        status: advisory?.status || 'Draft',
        schedules
      });

      setAdvisory(updated);
      setSuccessMessage('Advisory changes saved successfully.');
    } catch (err: any) {
      setError(err.message || 'Failed to save advisory changes.');
    } finally {
      setSaving(false);
    }
  };

  // Publish
  const handlePublish = async () => {
    if (!id) return;
    setPublishing(true);
    setError(null);

    try {
      if (!schedules || schedules.length === 0) {
        setError('Cannot publish advisory with 0 schedules. Please define at least one schedule or click "Re-parse Advisory".');
        setIsPublishModalOpen(false);
        setPublishing(false);
        return;
      }

      const activeSchedules = schedules.filter(s => s.areas && s.areas.length > 0);
      if (activeSchedules.length === 0) {
        setError('Cannot publish advisory without any affected areas. Please add areas to at least one schedule window.');
        setIsPublishModalOpen(false);
        setPublishing(false);
        return;
      }

      const published = await advisoryService.publishAdvisory(id, {
        title,
        source,
        sourceUrl: sourceUrl.trim() || undefined,
        startDate,
        endDate,
        schedules: activeSchedules
      });

      setAdvisory(published);
      if (published.schedules) {
        setSchedules(published.schedules.map(s => ({
          id: s.id,
          scheduleDate: s.scheduleDate,
          startTime: s.startTime,
          endTime: s.endTime,
          scheduleType: s.scheduleType,
          areas: s.areas.map(a => ({
            rawAreaName: a.rawAreaName || a.name,
            city: a.city,
            matchedAreaId: a.id,
            isMatched: true
          }))
        })));
      }
      setIsPublishModalOpen(false);
      setSuccessMessage('Advisory published successfully! It is now live on the public interactive map.');
    } catch (err: any) {
      setError(err.message || 'Failed to publish advisory to the map.');
      setIsPublishModalOpen(false);
    } finally {
      setPublishing(false);
    }
  };

  // Archive
  const handleArchive = async () => {
    if (!id || !window.confirm('Are you sure you want to archive this advisory?')) return;
    try {
      const archived = await advisoryService.archiveAdvisory(id);
      setAdvisory(archived);
      setSuccessMessage('Advisory moved to Archived status.');
    } catch (err: any) {
      setError(err.message || 'Failed to archive advisory.');
    }
  };

  if (loading) return <LoadingState message="Loading advisory details for review..." />;
  if (!advisory) {
    return (
      <div className="p-6 text-center">
        <p className="text-slate-600">Advisory not found.</p>
        <Link to="/admin/advisories" className="text-amber-600 underline mt-2 inline-block">
          Return to Advisories List
        </Link>
      </div>
    );
  }

  // Count total areas and unmatched areas
  let totalAreas = 0;
  let unmatchedCount = 0;
  schedules.forEach(s => {
    s.areas.forEach(a => {
      totalAreas++;
      if (!a.isMatched) unmatchedCount++;
    });
  });

  const cityOptions = [
    { value: 'Cebu City', label: 'Cebu City' },
    { value: 'Mandaue City', label: 'Mandaue City' },
    { value: 'Talisay City', label: 'Talisay City' },
    { value: 'Consolacion', label: 'Consolacion' },
    { value: 'Liloan', label: 'Liloan' },
    { value: 'Minglanilla', label: 'Minglanilla' },
    { value: 'City of Naga', label: 'City of Naga' },
    { value: 'San Fernando', label: 'San Fernando' }
  ];

  return (
    <div className="space-y-6">
      {/* Top Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div className="flex items-center gap-3">
          <Link
            to="/admin/advisories"
            className="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
          </Link>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Advisory Review
              </span>
              <Badge
                variant={
                  advisory.status === 'Published'
                    ? 'green'
                    : advisory.status === 'Draft'
                    ? 'amber'
                    : 'slate'
                }
                size="sm"
                dot={advisory.status === 'Published'}
              >
                {advisory.status}
              </Badge>
            </div>
            <h1 className="text-xl font-extrabold text-slate-950 truncate max-w-lg">
              {title || 'Untitled Advisory'}
            </h1>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={handleReparse}
            icon={<RefreshCw className="w-3.5 h-3.5" />}
          >
            Re-Parse Text
          </Button>

          <Button
            type="button"
            variant="outline"
            size="sm"
            isLoading={saving}
            onClick={handleSave}
            icon={<Save className="w-3.5 h-3.5" />}
          >
            Save Draft
          </Button>

          {advisory.status === 'Published' ? (
            <>
              <Link to="/" target="_blank">
                <Button size="sm" variant="outline" icon={<Eye className="w-3.5 h-3.5" />}>
                  View Live
                </Button>
              </Link>
              <Button
                size="sm"
                variant="danger"
                onClick={handleArchive}
                icon={<Archive className="w-3.5 h-3.5" />}
              >
                Archive
              </Button>
            </>
          ) : (
            <Button
              type="button"
              variant="secondary"
              size="sm"
              onClick={() => setIsPublishModalOpen(true)}
              icon={<Send className="w-3.5 h-3.5" />}
            >
              Publish to Map
            </Button>
          )}
        </div>
      </div>

      {/* Messages */}
      {error && (
        <Alert
          type="error"
          title="Publish / Validation Notice"
          action={
            schedules.length === 0 ? (
              <Button
                size="sm"
                variant="outline"
                onClick={handleReparse}
                icon={<RefreshCw className="w-3.5 h-3.5" />}
              >
                Re-Parse Text Now
              </Button>
            ) : undefined
          }
        >
          {error}
        </Alert>
      )}
      {successMessage && (
        <Alert type="success" title="Success">
          {successMessage}
        </Alert>
      )}

      {/* Unmatched Warning Alert */}
      {unmatchedCount > 0 && (
        <Alert type="warning" title={`${unmatchedCount} Unrecognized Area(s) Detected`}>
          Some barangays in this advisory were not automatically matched to our Metro Cebu database.
          Review the flagged areas below with the yellow badge and either link them to known barangays or register them so they display accurately on the interactive map.
        </Alert>
      )}

      {/* Two Column Layout: Left Editor, Right Original Advisory */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        {/* Left 2 Cols: Form & Schedules */}
        <div className="lg:col-span-2 space-y-6">
          {/* Metadata Card */}
          <Card>
            <CardHeader>
              <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <FileText className="w-4 h-4 text-amber-500" />
                Advisory Details
              </h2>
            </CardHeader>
            <CardBody className="space-y-4">
              <Input
                label="Advisory Title"
                value={title}
                onChange={e => setTitle(e.target.value)}
                required
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input
                  label="Official Source"
                  value={source}
                  onChange={e => setSource(e.target.value)}
                  required
                />
                <Input
                  label="Source Facebook Post URL"
                  value={sourceUrl}
                  onChange={e => setSourceUrl(e.target.value)}
                  placeholder="https://facebook.com/..."
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input
                  label="Start Date"
                  type="date"
                  value={startDate}
                  onChange={e => setStartDate(e.target.value)}
                  required
                />
                <Input
                  label="End Date"
                  type="date"
                  value={endDate}
                  onChange={e => setEndDate(e.target.value)}
                  required
                />
              </div>
            </CardBody>
          </Card>

          {/* Schedules Section */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Clock className="w-5 h-5 text-amber-500" />
                  Possible Brownout Schedules ({schedules.length})
                </h2>
                <p className="text-xs text-slate-500">
                  {totalAreas} total affected barangay occurrences
                </p>
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={addSchedule}
                icon={<Plus className="w-3.5 h-3.5" />}
              >
                Add Schedule Window
              </Button>
            </div>

            {schedules.map((sched, sIdx) => (
              <Card key={sched.id || sIdx} className="border-slate-300">
                <CardHeader className="bg-slate-50/70 py-3">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-amber-100 text-amber-900 flex items-center justify-center font-bold text-xs">
                      {sIdx + 1}
                    </span>
                    <span className="font-bold text-slate-900 text-sm">
                      Schedule Window #{sIdx + 1}
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={() => removeSchedule(sIdx)}
                    className="text-slate-400 hover:text-rose-600 transition-colors p-1"
                    title="Remove this schedule window"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </CardHeader>

                <CardBody className="space-y-4 p-4 sm:p-5">
                  {/* Time and Date Fields */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <Input
                      label="Schedule Date"
                      type="date"
                      value={sched.scheduleDate}
                      onChange={e => updateScheduleField(sIdx, 'scheduleDate', e.target.value)}
                    />
                    <Input
                      label="Start Time"
                      value={sched.startTime}
                      placeholder="e.g. 10:00 AM"
                      onChange={e => updateScheduleField(sIdx, 'startTime', e.target.value)}
                    />
                    <Input
                      label="End Time"
                      value={sched.endTime}
                      placeholder="e.g. 12:30 PM"
                      onChange={e => updateScheduleField(sIdx, 'endTime', e.target.value)}
                    />
                  </div>

                  {/* Areas List */}
                  <div className="space-y-2.5 pt-2 border-t border-slate-100">
                    <label className="text-xs font-semibold text-slate-700 uppercase tracking-wide flex items-center justify-between">
                      <span>Affected Barangays ({sched.areas.length})</span>
                      <span className="text-[11px] text-slate-400 font-normal">
                        Click &times; to remove or select match
                      </span>
                    </label>

                    {/* Area Badges with status */}
                    <div className="flex flex-wrap gap-2 min-h-[36px] p-2 bg-slate-50 rounded-lg border border-slate-200">
                      {sched.areas.length === 0 ? (
                        <span className="text-xs text-rose-500 italic p-1">
                          No areas added yet. Every schedule must have at least one affected area.
                        </span>
                      ) : (
                        sched.areas.map((area, aIdx) => (
                          <div
                            key={aIdx}
                            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs border transition-colors ${
                              area.isMatched
                                ? 'bg-white text-slate-900 border-slate-300'
                                : 'bg-amber-100/80 text-amber-950 border-amber-400 ring-1 ring-amber-300'
                            }`}
                          >
                            {area.isMatched ? (
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                            ) : (
                              <AlertTriangle className="w-3.5 h-3.5 text-amber-700 shrink-0" />
                            )}
                            <span className="font-medium">{area.rawAreaName}</span>
                            <span className="text-[10px] text-slate-500">({area.city})</span>

                            {!area.isMatched && (
                              <button
                                type="button"
                                onClick={() => {
                                  setActiveAreaTarget({ schedIdx: sIdx, areaIdx: aIdx });
                                  setNewAreaName(area.rawAreaName);
                                  setNewAreaCity(area.city);
                                  setIsNewAreaModalOpen(true);
                                }}
                                className="text-[10px] text-blue-700 hover:text-blue-900 font-bold underline ml-1 cursor-pointer"
                              >
                                Fix
                              </button>
                            )}

                            <button
                              type="button"
                              onClick={() => removeAreaFromSchedule(sIdx, aIdx)}
                              className="text-slate-400 hover:text-rose-600 ml-1 rounded p-0.5"
                            >
                              &times;
                            </button>
                          </div>
                        ))
                      )}
                    </div>

                    {/* Add Area Line */}
                    <div className="flex flex-col sm:flex-row items-center gap-2 pt-1">
                      <div className="w-full sm:w-1/3">
                        <select
                          className="w-full text-xs p-2 border border-slate-300 rounded-lg bg-white"
                          value={newAreaInputs[sIdx]?.city || 'Cebu City'}
                          onChange={e =>
                            setNewAreaInputs({
                              ...newAreaInputs,
                              [sIdx]: {
                                name: newAreaInputs[sIdx]?.name || '',
                                city: e.target.value
                              }
                            })
                          }
                        >
                          {cityOptions.map(c => (
                            <option key={c.value} value={c.value}>
                              {c.label}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="flex-1 w-full">
                        <input
                          type="text"
                          placeholder="Type barangay name (e.g. Guadalupe, Lahug)"
                          className="w-full text-xs p-2 border border-slate-300 rounded-lg bg-white"
                          value={newAreaInputs[sIdx]?.name || ''}
                          onChange={e =>
                            setNewAreaInputs({
                              ...newAreaInputs,
                              [sIdx]: {
                                name: e.target.value,
                                city: newAreaInputs[sIdx]?.city || 'Cebu City'
                              }
                            })
                          }
                          onKeyDown={e => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              addAreaToSchedule(sIdx);
                            }
                          }}
                        />
                      </div>

                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => addAreaToSchedule(sIdx)}
                        className="w-full sm:w-auto"
                      >
                        Add Area
                      </Button>
                    </div>
                  </div>
                </CardBody>
              </Card>
            ))}
          </div>
        </div>

        {/* Right 1 Col: Original Advisory Reference */}
        <div className="space-y-4">
          <Card className="sticky top-20">
            <CardHeader className="bg-slate-900 text-white">
              <div className="flex items-center justify-between w-full">
                <span className="font-bold text-sm flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-amber-400" />
                  Original Advisory Text
                </span>
                <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded">
                  Preserved
                </span>
              </div>
            </CardHeader>
            <CardBody className="p-4 space-y-3">
              <p className="text-xs text-slate-500">
                The original Facebook post text is strictly preserved alongside the structured schedules for transparency.
              </p>
              <div className="max-h-[500px] overflow-y-auto bg-slate-50 p-3 rounded-lg border border-slate-200 font-mono text-xs text-slate-800 whitespace-pre-wrap leading-relaxed select-all">
                {advisory.originalContent}
              </div>

              {advisory.sourceUrl && (
                <a
                  href={advisory.sourceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-600 hover:text-blue-800"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  Open Original Facebook Post
                </a>
              )}
            </CardBody>
          </Card>
        </div>
      </div>

      {/* Confirmation Modal Before Publishing */}
      <Modal
        isOpen={isPublishModalOpen}
        onClose={() => setIsPublishModalOpen(false)}
        title="Confirm Advisory Publication"
        footer={
          <>
            <Button variant="outline" onClick={() => setIsPublishModalOpen(false)}>
              Cancel
            </Button>
            {schedules.length === 0 ? (
              <Button
                variant="primary"
                onClick={async () => {
                  await handleReparse();
                  setIsPublishModalOpen(false);
                }}
                icon={<RefreshCw className="w-4 h-4" />}
              >
                Re-Parse Advisory Now
              </Button>
            ) : (
              <Button
                variant="secondary"
                isLoading={publishing}
                onClick={handlePublish}
                icon={<Send className="w-4 h-4" />}
              >
                Confirm & Publish Now
              </Button>
            )}
          </>
        }
      >
        <div className="space-y-3 text-sm text-slate-700">
          {schedules.length === 0 ? (
            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-900 space-y-2">
              <div className="font-semibold text-rose-950">No schedules extracted yet</div>
              <p>
                This advisory post currently has 0 detected schedule windows. Click <strong>Re-Parse Advisory Now</strong> to automatically extract the schedule time blocks and barangays from the original advisory text.
              </p>
            </div>
          ) : (
            <>
              <p>
                Are you sure you want to publish this advisory to the public map?
              </p>
              <div className="p-3 bg-amber-50 rounded-lg border border-amber-200 text-xs text-amber-950 space-y-1">
                <div><strong>Advisory:</strong> {title}</div>
                <div><strong>Date:</strong> {formatDate(startDate)} – {formatDate(endDate)}</div>
                <div><strong>Schedules:</strong> {schedules.length} time windows</div>
                <div><strong>Total Areas:</strong> {totalAreas} barangay assignments</div>
              </div>
              <p className="text-xs text-slate-500">
                Once published, these schedules will appear immediately on the public interactive map and search results for residents across Metro Cebu.
              </p>
            </>
          )}
        </div>
      </Modal>

      {/* Modal to Register / Match an Unrecognized Area */}
      <Modal
        isOpen={isNewAreaModalOpen}
        onClose={() => setIsNewAreaModalOpen(false)}
        title="Resolve Unrecognized Area"
        footer={
          <>
            <Button variant="outline" onClick={() => setIsNewAreaModalOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" onClick={handleRegisterNewArea}>
              Save & Register Barangay
            </Button>
          </>
        }
      >
        <div className="space-y-4">
          <p className="text-xs text-slate-600">
            Link this parsed text to a known barangay or register it as a new area in the PowerWatch database.
          </p>

          <Input
            label="Barangay Name"
            value={newAreaName}
            onChange={e => setNewAreaName(e.target.value)}
          />

          <Select
            label="City / Municipality"
            value={newAreaCity}
            onChange={e => setNewAreaCity(e.target.value)}
            options={cityOptions}
          />

          {/* Quick pick from known areas */}
          <div className="space-y-1.5 pt-2 border-t border-slate-100">
            <label className="text-xs font-semibold text-slate-700">
              Or match with existing registered barangay:
            </label>
            <select
              className="w-full text-xs p-2 border border-slate-300 rounded-lg bg-white"
              onChange={e => {
                if (e.target.value && activeAreaTarget) {
                  assignKnownArea(activeAreaTarget.schedIdx, activeAreaTarget.areaIdx, e.target.value);
                  setIsNewAreaModalOpen(false);
                }
              }}
            >
              <option value="">-- Select matching registered barangay --</option>
              {knownAreas.map(a => (
                <option key={a.id} value={a.id}>
                  {a.name} ({a.city})
                </option>
              ))}
            </select>
          </div>
        </div>
      </Modal>
    </div>
  );
}
