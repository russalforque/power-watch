import React, { useEffect, useState } from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import { ExternalLink, Lock, Zap, ArrowUpRight, ShieldCheck, MapPin } from 'lucide-react';
import { advisoryService, ActiveAdvisoryResponse } from '../services/advisoryService';
import { formatDateRange, formatDateTime } from '../utils/formatters';

export function PublicLayout() {
  const location = useLocation();
  const [activeData, setActiveData] = useState<ActiveAdvisoryResponse | null>(null);

  useEffect(() => {
    advisoryService.getActiveAdvisory().then(setActiveData).catch(() => {});
  }, []);

  const advisory = activeData?.advisory;

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF9F6] text-slate-900 font-sans antialiased selection:bg-amber-400 selection:text-slate-950">
      {/* Top Editorial Civic Header */}
      <header className="sticky top-0 z-40 bg-[#FAF9F6]/90 backdrop-blur-md border-b border-slate-200/80 transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          {/* Brand Logo & Editorial Monogram */}
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="w-8 h-8 rounded-lg bg-slate-950 flex items-center justify-center text-amber-400 group-hover:scale-105 transition-transform duration-200 shadow-xs">
              <Zap className="w-4 h-4 fill-current" />
            </div>
            <div className="flex flex-col">
              <div className="flex items-center gap-1.5">
                <span className="font-display font-extrabold text-base tracking-tight text-slate-950 uppercase">
                  POWERWATCH
                </span>
                <span className="hidden sm:inline-block text-[10px] font-mono uppercase tracking-widest px-1.5 py-0.5 rounded bg-slate-200/70 text-slate-700 font-medium">
                  Cebu
                </span>
              </div>
              <span className="text-[10px] font-sans text-slate-500 hidden sm:block -mt-0.5">
                Know before the lights go out.
              </span>
            </div>
          </Link>

          {/* Navigation Links */}
          <nav className="flex items-center gap-1 sm:gap-6 text-sm">
            <div className="hidden md:flex items-center gap-6 font-medium text-slate-600">
              <a
                href="#schedule"
                className="hover:text-slate-950 transition-colors py-1"
              >
                Schedule
              </a>
              <a
                href="#find-area"
                className="hover:text-slate-950 transition-colors py-1"
              >
                Find Area
              </a>
              <a
                href="#map-section"
                className="hover:text-slate-950 transition-colors py-1"
              >
                Map
              </a>
              <a
                href="#advisory-section"
                className="hover:text-slate-950 transition-colors py-1"
              >
                Advisories
              </a>
              <a
                href="#source-section"
                className="hover:text-slate-950 transition-colors py-1 text-slate-500 hover:text-slate-800"
              >
                Sources
              </a>
            </div>

            <div className="flex items-center gap-2 sm:gap-3 pl-2 sm:pl-4 sm:border-l sm:border-slate-200">
              <a
                href="https://www.facebook.com/visayanelectric"
                target="_blank"
                rel="noopener noreferrer"
                className="hidden lg:inline-flex items-center gap-1 text-xs text-slate-500 hover:text-slate-900 transition-colors"
                title="Visayan Electric Official Facebook Page"
              >
                <span>VECO Public Post</span>
                <ExternalLink className="w-3 h-3 text-slate-400" />
              </a>

              <Link
                to="/admin"
                className="text-xs font-mono font-medium px-3 py-1.5 rounded-lg border border-slate-300/80 bg-white/80 hover:bg-slate-950 hover:text-white hover:border-slate-950 text-slate-700 transition-all duration-150 inline-flex items-center gap-1.5 shadow-2xs"
              >
                <Lock className="w-3 h-3 text-slate-400 group-hover:text-amber-400" />
                <span>Admin</span>
              </Link>
            </div>
          </nav>
        </div>
      </header>

      {/* Main Viewport Container */}
      <main className="flex-1 w-full">
        <Outlet />
      </main>

      {/* Large Editorial Civic Footer */}
      <footer className="bg-slate-950 text-slate-300 border-t border-slate-900 pt-16 pb-12 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          {/* Top Brand & Mission Banner */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 pb-12 border-b border-slate-800/80 items-start">
            <div className="lg:col-span-6 space-y-4">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-amber-400 flex items-center justify-center text-slate-950 font-black">
                  <Zap className="w-4 h-4 fill-current" />
                </div>
                <span className="font-display font-extrabold text-xl tracking-tight text-white uppercase">
                  POWERWATCH
                </span>
                <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                  Metro Cebu Grid
                </span>
              </div>

              <h2 className="font-display text-2xl sm:text-3xl font-bold text-white tracking-tight leading-snug">
                Know before the lights go out.
              </h2>
              <p className="text-sm text-slate-400 max-w-lg leading-relaxed font-light">
                PowerWatch is a civic open-information platform designed to structure, map, and clearly present possible rotational brownout schedules from official Visayan Electric advisories across Metro Cebu.
              </p>
            </div>

            {/* Quick Navigation Columns */}
            <div className="lg:col-span-6 grid grid-cols-2 sm:grid-cols-3 gap-6 text-xs">
              <div className="space-y-3">
                <span className="font-mono text-slate-500 uppercase tracking-wider block font-semibold">
                  Navigation
                </span>
                <ul className="space-y-2 text-slate-300">
                  <li><a href="#hero-search" className="hover:text-white transition-colors">Find Your Barangay</a></li>
                  <li><a href="#schedule" className="hover:text-white transition-colors">Today's Schedule</a></li>
                  <li><a href="#map-section" className="hover:text-white transition-colors">Geographic Map</a></li>
                  <li><a href="#advisory-section" className="hover:text-white transition-colors">Latest Advisory</a></li>
                  <li><a href="#timeline-section" className="hover:text-white transition-colors">Hourly Timeline</a></li>
                </ul>
              </div>

              <div className="space-y-3">
                <span className="font-mono text-slate-500 uppercase tracking-wider block font-semibold">
                  Coverage
                </span>
                <ul className="space-y-2 text-slate-400">
                  <li>Cebu City</li>
                  <li>Mandaue City</li>
                  <li>Talisay City</li>
                  <li>Consolacion & Liloan</li>
                  <li>Minglanilla & Naga</li>
                  <li>San Fernando</li>
                </ul>
              </div>

              <div className="space-y-3 col-span-2 sm:col-span-1">
                <span className="font-mono text-slate-500 uppercase tracking-wider block font-semibold">
                  Source & Trust
                </span>
                <ul className="space-y-2 text-slate-300">
                  <li>
                    <a
                      href="https://www.facebook.com/visayanelectric"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:text-amber-400 flex items-center gap-1 transition-colors"
                    >
                      <span>Visayan Electric</span>
                      <ArrowUpRight className="w-3 h-3 text-slate-500" />
                    </a>
                  </li>
                  <li>
                    <a
                      href="https://www.ngcp.ph/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="hover:text-amber-400 flex items-center gap-1 transition-colors"
                    >
                      <span>NGCP Grid Updates</span>
                      <ArrowUpRight className="w-3 h-3 text-slate-500" />
                    </a>
                  </li>
                  <li><a href="#disclaimer-section" className="hover:text-white transition-colors">Grid Notice</a></li>
                  <li><Link to="/admin" className="hover:text-white transition-colors">Advisory Import Portal</Link></li>
                </ul>
              </div>
            </div>
          </div>

          {/* Bottom Information Disclaimer */}
          <div className="space-y-3 text-xs text-slate-400 font-light leading-relaxed max-w-4xl">
            <p className="text-slate-300 font-normal">
              <strong className="text-amber-400 uppercase tracking-wider font-mono mr-1">Public Notice:</strong>
              PowerWatch is an independent community project and is not officially affiliated with Visayan Electric Company (VECO) or the National Grid Corporation of the Philippines (NGCP). All data is sourced directly from publicly released utility advisories. Rotational brownout windows are contingent upon actual generation capacity and NGCP dispatch directives.
            </p>
          </div>

          {/* Copyright Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-slate-500 pt-6 border-t border-slate-900">
            <div>
              © {new Date().getFullYear()} PowerWatch Metro Cebu. Built for community resilience.
            </div>
            <div className="flex items-center gap-4">
              <span>Status: Operating Normally</span>
              {advisory && (
                <span>• Synced: {formatDateTime(advisory.updatedAt)}</span>
              )}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
