import React, { useEffect, useRef, useState, useMemo } from 'react';
import L from 'leaflet';
import {
  Plus,
  Minus,
  Crosshair,
  Maximize2,
  Minimize2,
  Layers,
  MapPin,
  Navigation,
  Clock,
  Radio,
  X
} from 'lucide-react';
import { Area, BrownoutSchedule, BrownoutPost } from '../../types';
import { formatDate, getScheduleTimeStatus } from '../../utils/formatters';

// ==========================================
// Types & Interfaces
// ==========================================

export interface MapAreaSchedule {
  area: Area;
  schedules: {
    schedule: BrownoutSchedule;
    post?: BrownoutPost;
    timeWindow?: string;
  }[];
}

export type MapTileStyle = 'positron' | 'dark' | 'standard';

interface PowerWatchMapProps {
  affectedAreas: MapAreaSchedule[];
  selectedAreaId?: string | null;
  onSelectArea?: (areaId: string) => void;
  height?: string;
  focusCoordinates?: [number, number] | null;
}

const CITY_COORDINATES: Record<string, { center: [number, number]; zoom: number }> = {
  'All Cebu': { center: [10.3157, 123.8854], zoom: 12 },
  'Cebu City': { center: [10.3157, 123.8854], zoom: 13 },
  'Mandaue City': { center: [10.3321, 123.9357], zoom: 13 },
  'Talisay City': { center: [10.2555, 123.8398], zoom: 13 },
  'Consolacion': { center: [10.3783, 123.9575], zoom: 13 },
  'Liloan': { center: [10.4042, 123.9786], zoom: 13 },
  'Minglanilla': { center: [10.2444, 123.7963], zoom: 13 },
  'City of Naga': { center: [10.2072, 123.7578], zoom: 13 },
  'San Fernando': { center: [10.1622, 123.7094], zoom: 13 }
};

const TILE_PROVIDERS: Record<MapTileStyle, { url: string; attribution: string; name: string }> = {
  positron: {
    name: 'Minimal Light',
    url: 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png',
    attribution: '&copy; <a href="https://carto.com/">CARTO</a> &copy; OpenStreetMap contributors'
  },
  dark: {
    name: 'Monochrome Dark',
    url: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
    attribution: '&copy; <a href="https://carto.com/">CARTO</a> &copy; OpenStreetMap contributors'
  },
  standard: {
    name: 'OpenStreetMap',
    url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
  }
};

// ==========================================
// Redesigned Minimalist PowerWatchMap
// ==========================================

export function PowerWatchMap({
  affectedAreas,
  selectedAreaId,
  onSelectArea,
  height = '580px',
  focusCoordinates
}: PowerWatchMapProps) {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const tileLayerRef = useRef<L.TileLayer | null>(null);
  const markersRef = useRef<Record<string, L.CircleMarker>>({});
  const userMarkerRef = useRef<L.CircleMarker | null>(null);

  const [tileStyle, setTileStyle] = useState<MapTileStyle>('positron');
  const [activeCityPill, setActiveCityPill] = useState<string>('All Cebu');
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [isLocating, setIsLocating] = useState<boolean>(false);
  const [locationStatus, setLocationStatus] = useState<string | null>(null);
  const [showStyleMenu, setShowStyleMenu] = useState<boolean>(false);

  // Calculate active vs upcoming count
  const stats = useMemo(() => {
    let ongoingCount = 0;
    let upcomingCount = 0;

    affectedAreas.forEach(item => {
      let isOngoing = false;
      let isUpcoming = false;
      item.schedules.forEach(s => {
        const st = getScheduleTimeStatus(s.schedule.scheduleDate, s.schedule.startTime, s.schedule.endTime);
        if (st === 'ongoing') isOngoing = true;
        if (st === 'upcoming') isUpcoming = true;
      });
      if (isOngoing) ongoingCount++;
      else if (isUpcoming) upcomingCount++;
    });

    return {
      total: affectedAreas.length,
      ongoing: ongoingCount,
      upcoming: upcomingCount
    };
  }, [affectedAreas]);

  // 1. Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current || mapInstanceRef.current) return;

    const defaultCenter: [number, number] = [10.3157, 123.8854];
    const defaultZoom = 12;

    const map = L.map(mapContainerRef.current, {
      center: defaultCenter,
      zoom: defaultZoom,
      zoomControl: false, // Using our sleek minimalist controls
      scrollWheelZoom: true,
      attributionControl: false
    });

    // Add Minimalist Attribution in bottom right
    L.control.attribution({ position: 'bottomright', prefix: false }).addTo(map);

    // Initial Minimalist Positron Tile Layer
    const provider = TILE_PROVIDERS.positron;
    const tileLayer = L.tileLayer(provider.url, {
      attribution: provider.attribution,
      maxZoom: 19,
      minZoom: 9,
      subdomains: 'abcd'
    }).addTo(map);

    tileLayerRef.current = tileLayer;
    mapInstanceRef.current = map;

    return () => {
      map.remove();
      mapInstanceRef.current = null;
      tileLayerRef.current = null;
    };
  }, []);

  // 2. Handle Tile Layer Switch
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (tileLayerRef.current) {
      tileLayerRef.current.remove();
    }

    const provider = TILE_PROVIDERS[tileStyle];
    tileLayerRef.current = L.tileLayer(provider.url, {
      attribution: provider.attribution,
      maxZoom: 19,
      minZoom: 9,
      subdomains: 'abcd'
    }).addTo(map);
  }, [tileStyle]);

  // 3. Render Minimalist Area Markers
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // Remove existing markers
    Object.values(markersRef.current).forEach(m => m.remove());
    markersRef.current = {};

    const bounds = L.latLngBounds([]);

    affectedAreas.forEach(({ area, schedules }) => {
      if (!area.latitude || !area.longitude) return;

      const isSelected = selectedAreaId === area.id;

      // Determine schedule status across windows
      let hasOngoing = false;
      let hasUpcoming = false;
      schedules.forEach(s => {
        const st = getScheduleTimeStatus(s.schedule.scheduleDate, s.schedule.startTime, s.schedule.endTime);
        if (st === 'ongoing') hasOngoing = true;
        if (st === 'upcoming') hasUpcoming = true;
      });

      // Editorial Civic Color Language:
      // Amber/Yellow (#f59e0b / #d97706) = Possible Rotational Brownout
      // Electric Blue = Selected Area Halo
      let fillColor = '#f59e0b'; // Warm amber
      let strokeColor = '#ffffff';
      let radius = 7;
      let strokeWidth = 2;
      let fillOpacity = 0.9;

      if (hasOngoing) {
        fillColor = '#d97706'; // Deep energetic amber
        radius = 9;
        strokeWidth = 2.5;
        strokeColor = '#fef3c7';
      }

      if (isSelected) {
        fillColor = '#f59e0b';
        strokeColor = '#1e3a8a'; // Deep electric navy border
        radius = 12;
        strokeWidth = 3.5;
        fillOpacity = 1;
      }

      const marker = L.circleMarker([area.latitude, area.longitude], {
        radius,
        fillColor,
        fillOpacity,
        color: strokeColor,
        weight: strokeWidth
      });

      // Editorial Civic High-Contrast Popup
      const schedulesListHtml = schedules
        .map(s => {
          const st = getScheduleTimeStatus(s.schedule.scheduleDate, s.schedule.startTime, s.schedule.endTime);
          const isCurrentWindow = st === 'ongoing';

          return `
            <div class="py-2 px-2.5 rounded-lg ${
              isCurrentWindow
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                : 'bg-slate-800/80 text-slate-200 border border-slate-700/60'
            } text-xs flex items-center justify-between font-mono">
              <span class="text-slate-400 font-sans">${s.schedule.scheduleDate ? formatDate(s.schedule.scheduleDate) : 'Today'}</span>
              <span class="font-bold text-white tracking-tight">${s.schedule.startTime} – ${s.schedule.endTime}</span>
            </div>
          `;
        })
        .join('');

      const popupHtml = `
        <div class="p-4 space-y-3 font-sans min-w-[230px] text-white">
          <div class="space-y-1 border-b border-slate-800 pb-2.5">
            <span class="text-[10px] font-mono uppercase tracking-widest text-slate-400 block">${area.city}</span>
            <h4 class="text-base font-bold tracking-tight text-white font-display">${area.name}</h4>
            <div class="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[11px] font-medium border border-amber-500/30 mt-1">
              <span class="w-1.5 h-1.5 rounded-full bg-amber-400 inline-block animate-pulse"></span>
              <span>Possible Rotational Brownout</span>
            </div>
          </div>

          <div class="space-y-1.5">
            <div class="text-[10px] font-mono uppercase tracking-wider text-slate-400 flex items-center justify-between">
              <span>Time Windows</span>
              <span>${schedules.length} ${schedules.length === 1 ? 'window' : 'windows'}</span>
            </div>
            <div class="space-y-1.5 max-h-40 overflow-y-auto pr-0.5">
              ${schedulesListHtml}
            </div>
          </div>

          <div class="pt-2 text-[10px] font-mono text-slate-400 flex items-center justify-between border-t border-slate-800">
            <span>Visayan Electric</span>
            <span class="${hasOngoing ? 'text-amber-400 font-semibold' : 'text-slate-300'}">
              ${hasOngoing ? '• Active Window' : 'Scheduled'}
            </span>
          </div>
        </div>
      `;

      marker.bindPopup(popupHtml, {
        maxWidth: 260,
        className: 'minimal-popup'
      });

      // Lightweight Hover Tooltip
      marker.bindTooltip(`${area.name} (${area.city})`, {
        direction: 'top',
        offset: [0, -6],
        className: 'leaflet-tooltip-minimal',
        opacity: 0.95
      });

      marker.on('click', () => {
        if (onSelectArea) {
          onSelectArea(area.id);
        }
      });

      marker.addTo(map);
      markersRef.current[area.id] = marker;
      bounds.extend([area.latitude, area.longitude]);
    });

    // Fit bounds smoothly on initial load
    if (affectedAreas.length > 0 && !selectedAreaId && !focusCoordinates) {
      map.fitBounds(bounds, { padding: [40, 40], maxZoom: 13 });
    }
  }, [affectedAreas, selectedAreaId, onSelectArea, tileStyle]);

  // 4. Focus / Selected Area animation
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (focusCoordinates) {
      map.flyTo(focusCoordinates, 14, { duration: 1.1 });
    } else if (selectedAreaId && markersRef.current[selectedAreaId]) {
      const marker = markersRef.current[selectedAreaId];
      const latLng = marker.getLatLng();
      map.flyTo(latLng, 14, { duration: 1 });
      marker.openPopup();
    }
  }, [selectedAreaId, focusCoordinates]);

  // City Jump Action
  const handleCityJump = (city: string) => {
    setActiveCityPill(city);
    const map = mapInstanceRef.current;
    if (!map) return;

    const target = CITY_COORDINATES[city];
    if (target) {
      map.flyTo(target.center, target.zoom, { duration: 1.2 });
    }
  };

  // Reset to Metro Cebu Full View
  const handleResetView = () => {
    const map = mapInstanceRef.current;
    if (!map) return;
    setActiveCityPill('All Cebu');
    map.flyTo([10.3157, 123.8854], 12, { duration: 1 });
  };

  // Geolocation Locator
  const handleLocateMe = () => {
    if (!navigator.geolocation) {
      setLocationStatus('Geolocation is not supported by your browser.');
      return;
    }

    setIsLocating(true);
    setLocationStatus('Locating device...');

    navigator.geolocation.getCurrentPosition(
      pos => {
        setIsLocating(false);
        const { latitude, longitude } = pos.coords;
        const map = mapInstanceRef.current;
        if (!map) return;

        if (userMarkerRef.current) {
          userMarkerRef.current.remove();
        }

        // Add minimalist blue radar dot for user position
        const userMarker = L.circleMarker([latitude, longitude], {
          radius: 8,
          fillColor: '#3b82f6',
          fillOpacity: 1,
          color: '#ffffff',
          weight: 2
        });

        userMarker.bindPopup(`
          <div class="p-2.5 text-xs font-mono text-neutral-900 space-y-1">
            <div class="font-bold flex items-center gap-1.5">
              <span class="w-2 h-2 rounded-full bg-blue-500"></span>
              Your Location
            </div>
            <div class="text-[11px] text-neutral-500">
              Lat: ${latitude.toFixed(4)}, Lng: ${longitude.toFixed(4)}
            </div>
          </div>
        `).openPopup();

        userMarker.addTo(map);
        userMarkerRef.current = userMarker;

        map.flyTo([latitude, longitude], 14, { duration: 1.2 });
        setLocationStatus(null);
      },
      err => {
        setIsLocating(false);
        setLocationStatus('Could not access current location.');
        console.warn('Geolocation error:', err);
        setTimeout(() => setLocationStatus(null), 3000);
      },
      { timeout: 8000 }
    );
  };

  return (
    <div
      className={`relative w-full rounded-xl overflow-hidden border border-neutral-200/80 bg-neutral-100 transition-all duration-300 ${
        isFullscreen ? 'fixed inset-0 z-50 rounded-none h-screen w-screen' : ''
      }`}
    >
      {/* City Jump Quick Bar */}
      <nav
        aria-label="Municipality quick jumps"
        className="absolute top-3 left-3 right-16 z-[400] flex items-center gap-1.5 overflow-x-auto no-scrollbar pointer-events-auto pr-2"
      >
        {Object.keys(CITY_COORDINATES).map(city => (
          <button
            key={city}
            type="button"
            onClick={() => handleCityJump(city)}
            className={`text-xs font-mono px-2.5 py-1.5 rounded-lg whitespace-nowrap transition-all duration-150 backdrop-blur-md cursor-pointer ${
              activeCityPill === city
                ? 'bg-neutral-900 text-white shadow-xs font-medium'
                : 'bg-white/90 hover:bg-white text-neutral-600 hover:text-neutral-900 border border-neutral-200/70'
            }`}
          >
            {city}
          </button>
        ))}
      </nav>

      {/* Floating Minimalist Toolset (Top Right) */}
      <aside
        aria-label="Map view and zoom controls"
        className="absolute top-3 right-3 z-[400] flex flex-col items-center gap-1.5 pointer-events-auto"
      >
        {/* Fullscreen Toggle */}
        <button
          type="button"
          onClick={() => setIsFullscreen(!isFullscreen)}
          title={isFullscreen ? 'Exit Fullscreen' : 'Expand Map'}
          className="w-8 h-8 rounded-lg bg-white/95 hover:bg-white text-neutral-700 hover:text-neutral-900 border border-neutral-200/80 flex items-center justify-center transition-all shadow-xs cursor-pointer"
        >
          {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
        </button>

        {/* Tile Provider Layer Menu */}
        <div className="relative">
          <button
            type="button"
            onClick={() => setShowStyleMenu(!showStyleMenu)}
            title="Map Themes"
            className={`w-8 h-8 rounded-lg border border-neutral-200/80 flex items-center justify-center transition-all shadow-xs cursor-pointer ${
              showStyleMenu ? 'bg-neutral-900 text-white' : 'bg-white/95 hover:bg-white text-neutral-700 hover:text-neutral-900'
            }`}
          >
            <Layers className="w-4 h-4" />
          </button>

          {showStyleMenu && (
            <div className="absolute right-0 top-10 w-36 bg-white/95 backdrop-blur-md rounded-xl border border-neutral-200 shadow-md p-1.5 space-y-1 text-xs font-mono">
              {(['positron', 'dark', 'standard'] as MapTileStyle[]).map(styleKey => (
                <button
                  key={styleKey}
                  type="button"
                  onClick={() => {
                    setTileStyle(styleKey);
                    setShowStyleMenu(false);
                  }}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer ${
                    tileStyle === styleKey
                      ? 'bg-neutral-900 text-white font-medium'
                      : 'hover:bg-neutral-100 text-neutral-700'
                  }`}
                >
                  {TILE_PROVIDERS[styleKey].name}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Zoom Controls */}
        <div className="flex flex-col rounded-lg border border-neutral-200/80 bg-white/95 backdrop-blur-md overflow-hidden shadow-xs">
          <button
            type="button"
            onClick={() => mapInstanceRef.current?.zoomIn()}
            title="Zoom In"
            className="w-8 h-8 flex items-center justify-center text-neutral-700 hover:text-neutral-900 hover:bg-neutral-100/80 transition-colors border-b border-neutral-100 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => mapInstanceRef.current?.zoomOut()}
            title="Zoom Out"
            className="w-8 h-8 flex items-center justify-center text-neutral-700 hover:text-neutral-900 hover:bg-neutral-100/80 transition-colors cursor-pointer"
          >
            <Minus className="w-4 h-4" />
          </button>
        </div>

        {/* Recenter Metro Cebu */}
        <button
          type="button"
          onClick={handleResetView}
          title="Reset to Metro Cebu"
          className="w-8 h-8 rounded-lg bg-white/95 hover:bg-white text-neutral-700 hover:text-neutral-900 border border-neutral-200/80 flex items-center justify-center transition-all shadow-xs cursor-pointer"
        >
          <Crosshair className="w-4 h-4" />
        </button>

        {/* Geolocation */}
        <button
          type="button"
          onClick={handleLocateMe}
          title="Locate Me"
          disabled={isLocating}
          className={`w-8 h-8 rounded-lg bg-white/95 hover:bg-white text-neutral-700 hover:text-neutral-900 border border-neutral-200/80 flex items-center justify-center transition-all shadow-xs cursor-pointer ${
            isLocating ? 'animate-pulse text-blue-600' : ''
          }`}
        >
          <Navigation className="w-4 h-4" />
        </button>
      </aside>

      {/* Geolocation Feedback Toast */}
      {locationStatus && (
        <div className="absolute top-14 left-1/2 -translate-x-1/2 z-[400] bg-neutral-900 text-white text-xs font-mono px-3 py-1.5 rounded-lg shadow-md pointer-events-auto">
          {locationStatus}
        </div>
      )}

      {/* Leaflet Canvas Container */}
      <div
        ref={mapContainerRef}
        style={{ height: isFullscreen ? '100vh' : height, width: '100%' }}
        className="z-0"
      />

      {/* Minimalist Bottom Left Legend & Live Counter */}
      <footer
        aria-label="Map status and legend"
        className="absolute bottom-3 left-3 z-[400] pointer-events-auto bg-white/90 backdrop-blur-md rounded-xl border border-neutral-200/80 px-3 py-2 shadow-xs text-xs font-mono flex items-center gap-3 text-neutral-600"
      >
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-neutral-900 inline-block ring-2 ring-neutral-300" />
          <span className="text-neutral-900 font-medium">{stats.total}</span>
          <span className="text-neutral-400">areas</span>
        </div>

        {stats.ongoing > 0 && (
          <>
            <span className="text-neutral-200">|</span>
            <div className="flex items-center gap-1.5 text-neutral-900 font-medium">
              <span className="relative flex h-1.5 w-1.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-neutral-900 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-neutral-900"></span>
              </span>
              <span>{stats.ongoing} active now</span>
            </div>
          </>
        )}

        <span className="text-neutral-200">|</span>
        <span className="text-[11px] text-neutral-400 hidden sm:inline">
          Click any point for schedule windows
        </span>
      </footer>
    </div>
  );
}
